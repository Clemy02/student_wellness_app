from django.shortcuts import render, redirect
from .forms import ReminderForm

reminders = [
]

def home(request):
    if request.method == 'POST' and 'task' in request.POST:
        form = ReminderForm(request.POST)
        if form.is_valid():
            reminders.append({'text': form.cleaned_data['task']})
    else:
        form = ReminderForm()

    return render(request, 'home.html', {'form': form, 'reminders': reminders})

def delete_reminder(request, item_id):
    if 0 <= item_id < len(reminders):
        del reminders[item_id]
    return redirect('home')


