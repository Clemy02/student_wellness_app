from django import forms

class ReminderForm(forms.Form):
    task = forms.CharField(label='New Reminder', max_length=100)
